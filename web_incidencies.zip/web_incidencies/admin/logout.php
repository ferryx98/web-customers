<?php
    session_start();
	$_SESSION["correu_usuari"]="";
	header("Location:login.php"); ?>
