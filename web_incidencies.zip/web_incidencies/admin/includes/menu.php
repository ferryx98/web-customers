<table width="90%">
	<tr>
		<td>Usuari:</td>
		<td><b><? echo $_SESSION["correu_usuari"] ?></b></td>
		<td>Manteniments:</td>
		<td><a href="admin_usuaris.php">Usuaris</a></td>
		<td><a href="admin_parroquies.php">Parròquies</a></td>
		<td><a href="admin_taula2.php">Admin taula 2</a></td>
		<td><a href="logout.php">Sortir</a></td>
	</tr>
</table>
